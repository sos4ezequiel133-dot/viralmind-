"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { User } from "@supabase/supabase-js"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Loader2, Save, Crown, LogOut } from "lucide-react"

interface Profile {
  id: string
  email: string | null
  full_name: string | null
  plan: string
  language: string
  generations_used: number
  created_at: string
}

interface SettingsFormProps {
  user: User | null
  profile: Profile | null
}

export function SettingsForm({ user, profile }: SettingsFormProps) {
  const [fullName, setFullName] = useState(profile?.full_name || "")
  const [language, setLanguage] = useState(profile?.language || "es")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)
  const router = useRouter()

  async function handleSave(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)
    setSuccess(false)

    const supabase = createClient()
    const { error } = await supabase
      .from("profiles")
      .update({ full_name: fullName, language })
      .eq("id", user?.id)

    if (!error) {
      setSuccess(true)
      setTimeout(() => setSuccess(false), 3000)
    }
    setLoading(false)
    router.refresh()
  }

  async function handleSignOut() {
    const supabase = createClient()
    await supabase.auth.signOut()
    router.push("/")
  }

  return (
    <div className="space-y-8">
      {/* Profile Section */}
      <div className="glass-card rounded-xl p-6">
        <h2 className="text-lg font-semibold text-foreground">Perfil</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Informacion basica de tu cuenta
        </p>

        <form onSubmit={handleSave} className="mt-6 space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="email">Correo electronico</Label>
              <Input
                id="email"
                type="email"
                value={user?.email || ""}
                disabled
                className="bg-muted"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="fullName">Nombre completo</Label>
              <Input
                id="fullName"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="bg-input border-border focus:border-primary"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="language">Idioma de generacion</Label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-full sm:w-48 bg-input border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="es">Espanol</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Las generaciones de IA se crearan en este idioma
            </p>
          </div>

          <div className="flex items-center gap-4">
            <Button
              type="submit"
              disabled={loading}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {loading ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Save className="mr-2 h-4 w-4" />
              )}
              Guardar Cambios
            </Button>
            {success && (
              <span className="text-sm text-green-500">Cambios guardados</span>
            )}
          </div>
        </form>
      </div>

      {/* Plan Section */}
      <div className="glass-card rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold text-foreground">Plan Actual</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Administra tu suscripcion
            </p>
          </div>
          <div className="flex items-center gap-2 rounded-full bg-primary/20 px-4 py-2">
            {profile?.plan === "pro" && <Crown className="h-4 w-4 text-primary" />}
            <span className="font-medium capitalize text-primary">{profile?.plan || "free"}</span>
          </div>
        </div>

        <div className="mt-6 rounded-lg bg-muted/30 p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-foreground">Generaciones hoy</p>
              <p className="text-xs text-muted-foreground">
                {profile?.plan === "pro" ? "Ilimitadas" : `${profile?.generations_used || 0} de ${profile?.plan === "starter" ? 50 : 5}`}
              </p>
            </div>
            {profile?.plan !== "pro" && (
              <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
                <Link href="/dashboard/upgrade">
                  <Crown className="mr-2 h-4 w-4" />
                  Actualizar
                </Link>
              </Button>
            )}
          </div>
        </div>

        <div className="mt-4 text-xs text-muted-foreground">
          Miembro desde: {new Date(profile?.created_at || "").toLocaleDateString("es")}
        </div>
      </div>

      {/* Danger Zone */}
      <div className="glass-card rounded-xl border-destructive/30 p-6">
        <h2 className="text-lg font-semibold text-foreground">Zona de Peligro</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Acciones irreversibles de la cuenta
        </p>

        <div className="mt-6">
          <Button
            variant="outline"
            className="border-destructive/50 text-destructive hover:bg-destructive/10"
            onClick={handleSignOut}
          >
            <LogOut className="mr-2 h-4 w-4" />
            Cerrar Sesion
          </Button>
        </div>
      </div>
    </div>
  )
}
