"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { FileText, Loader2, Sparkles, Heart, Copy, Check, Download } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Script {
  title: string
  hook: string
  intro: string
  body: string[]
  climax: string
  cta: string
  totalDuration: string
  visualNotes: string[]
}

interface ScriptGeneratorProps {
  userId: string
  plan: string
  generationsUsed: number
}

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export function ScriptGenerator({ userId, plan, generationsUsed }: ScriptGeneratorProps) {
  const [topic, setTopic] = useState("")
  const [duration, setDuration] = useState("60")
  const [style, setStyle] = useState("educativo")
  const [script, setScript] = useState<Script | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copied, setCopied] = useState(false)

  const limit = planLimits[plan]
  const remaining = Math.max(0, limit - generationsUsed)

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault()
    if (!topic.trim()) return

    setLoading(true)
    setError(null)
    setScript(null)

    try {
      const response = await fetch("/api/generate/script", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, duration, style, language: "es" }),
      })

      if (response.status === 429) {
        setError("Has alcanzado el limite del plan gratuito.")
        window.location.href = "/dashboard/upgrade"
        return
      }

      if (!response.ok) {
        throw new Error("Error al generar guion")
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullContent = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          fullContent += decoder.decode(value, { stream: true })
        }

        try {
          const parsed = JSON.parse(fullContent)
          setScript(parsed.script || null)
        } catch {
          setError("Error al procesar la respuesta")
        }
      }
    } catch {
      setError("Error de conexion. Intenta de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  async function handleFavorite() {
    if (!script) return
    const supabase = createClient()
    await supabase.from("generations").insert({
      user_id: userId,
      tool_type: "script",
      input_topic: topic,
      output_content: { script },
      is_favorite: true,
    })
  }

  function getFullScript(): string {
    if (!script) return ""
    return `${script.title}

HOOK (0-3s):
${script.hook}

INTRO (3-10s):
${script.intro}

CONTENIDO PRINCIPAL:
${script.body.map((point, i) => `${i + 1}. ${point}`).join("\n")}

CLIMAX:
${script.climax}

CALL TO ACTION:
${script.cta}

---
Duracion estimada: ${script.totalDuration}

NOTAS DE PRODUCCION:
${script.visualNotes.map((note) => `- ${note}`).join("\n")}`
  }

  function handleCopy() {
    navigator.clipboard.writeText(getFullScript())
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  function handleDownload() {
    const blob = new Blob([getFullScript()], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `guion-${topic.slice(0, 30).replace(/\s+/g, "-")}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
  }

  return (
    <div className="space-y-8">
      <form onSubmit={handleGenerate} className="space-y-4">
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="topic">Tema del video</Label>
            <Input
              id="topic"
              placeholder="Ej: Como ganar tu primer dolar en internet"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="bg-input border-border focus:border-primary"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="duration">Duracion</Label>
            <Select value={duration} onValueChange={setDuration}>
              <SelectTrigger className="bg-input border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="30">30 segundos</SelectItem>
                <SelectItem value="60">60 segundos</SelectItem>
                <SelectItem value="90">90 segundos</SelectItem>
                <SelectItem value="180">3 minutos</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="style">Estilo</Label>
            <Select value={style} onValueChange={setStyle}>
              <SelectTrigger className="bg-input border-border">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="educativo">Educativo</SelectItem>
                <SelectItem value="entretenimiento">Entretenimiento</SelectItem>
                <SelectItem value="storytime">Storytime</SelectItem>
                <SelectItem value="tutorial">Tutorial</SelectItem>
                <SelectItem value="motivacional">Motivacional</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <div className="flex items-center justify-between">
          <p className="text-xs text-muted-foreground">
            {plan === "pro" ? "Generaciones ilimitadas" : `${remaining} generaciones restantes hoy`}
          </p>
          <Button
            type="submit"
            disabled={loading || !topic.trim()}
            className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin" />
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4" />
                Generar Guion
              </>
            )}
          </Button>
        </div>
      </form>

      {error && (
        <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
          {error}
        </div>
      )}

      {script && (
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold text-foreground">{script.title}</h3>
            <div className="flex items-center gap-2">
              <Button variant="ghost" size="icon" onClick={handleFavorite}>
                <Heart className="h-4 w-4" />
              </Button>
              <Button variant="ghost" size="icon" onClick={handleCopy}>
                {copied ? <Check className="h-4 w-4 text-green-500" /> : <Copy className="h-4 w-4" />}
              </Button>
              <Button variant="ghost" size="icon" onClick={handleDownload}>
                <Download className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            {/* Hook */}
            <div className="glass-card rounded-xl p-5">
              <div className="flex items-center gap-2 text-primary">
                <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">1</div>
                <span className="font-medium">Hook (0-3s)</span>
              </div>
              <p className="mt-3 text-foreground">{script.hook}</p>
            </div>

            {/* Intro */}
            <div className="glass-card rounded-xl p-5">
              <div className="flex items-center gap-2 text-primary">
                <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">2</div>
                <span className="font-medium">Intro (3-10s)</span>
              </div>
              <p className="mt-3 text-foreground">{script.intro}</p>
            </div>

            {/* Body */}
            <div className="glass-card rounded-xl p-5 lg:col-span-2">
              <div className="flex items-center gap-2 text-primary">
                <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">3</div>
                <span className="font-medium">Contenido Principal</span>
              </div>
              <ul className="mt-3 space-y-2">
                {script.body.map((point, i) => (
                  <li key={i} className="flex items-start gap-2 text-foreground">
                    <span className="mt-1 h-1.5 w-1.5 rounded-full bg-primary flex-shrink-0" />
                    {point}
                  </li>
                ))}
              </ul>
            </div>

            {/* Climax */}
            <div className="glass-card rounded-xl p-5">
              <div className="flex items-center gap-2 text-primary">
                <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">4</div>
                <span className="font-medium">Climax</span>
              </div>
              <p className="mt-3 text-foreground">{script.climax}</p>
            </div>

            {/* CTA */}
            <div className="glass-card rounded-xl p-5">
              <div className="flex items-center gap-2 text-primary">
                <div className="h-6 w-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-bold">5</div>
                <span className="font-medium">Call to Action</span>
              </div>
              <p className="mt-3 text-foreground">{script.cta}</p>
            </div>

            {/* Visual notes */}
            <div className="glass-card rounded-xl p-5 lg:col-span-2">
              <p className="text-sm font-medium text-muted-foreground">Notas de Produccion</p>
              <ul className="mt-3 space-y-1">
                {script.visualNotes.map((note, i) => (
                  <li key={i} className="text-sm text-muted-foreground">
                    • {note}
                  </li>
                ))}
              </ul>
              <p className="mt-4 text-xs text-muted-foreground">
                Duracion estimada: <span className="text-foreground">{script.totalDuration}</span>
              </p>
            </div>
          </div>
        </div>
      )}

      {!loading && !script && !error && (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <FileText className="h-8 w-8 text-primary" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-foreground">
            Crea tu guion completo
          </h3>
          <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
            Genera guiones optimizados con hook, desarrollo, climax y call to action
          </p>
        </div>
      )}
    </div>
  )
}
