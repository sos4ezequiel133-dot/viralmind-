"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import {
  Lightbulb,
  MessageSquare,
  FileText,
  TrendingUp,
  Heart,
  Copy,
  Check,
  Trash2,
  History,
  Crown,
} from "lucide-react"

interface Generation {
  id: string
  tool_type: string
  input_topic: string
  output_content: Record<string, unknown>
  is_favorite: boolean
  created_at: string
}

interface HistoryListProps {
  generations: Generation[]
  plan: string
}

const toolIcons: Record<string, React.ElementType> = {
  idea: Lightbulb,
  hook: MessageSquare,
  script: FileText,
  trend: TrendingUp,
}

const toolNames: Record<string, string> = {
  idea: "Idea",
  hook: "Hook",
  script: "Guion",
  trend: "Tendencia",
}

export function HistoryList({ generations: initialGenerations, plan }: HistoryListProps) {
  const [generations, setGenerations] = useState(initialGenerations)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const router = useRouter()

  async function handleToggleFavorite(id: string, currentValue: boolean) {
    const supabase = createClient()
    await supabase
      .from("generations")
      .update({ is_favorite: !currentValue })
      .eq("id", id)
    
    setGenerations(generations.map((g) => 
      g.id === id ? { ...g, is_favorite: !currentValue } : g
    ))
  }

  async function handleDelete(id: string) {
    const supabase = createClient()
    await supabase.from("generations").delete().eq("id", id)
    setGenerations(generations.filter((g) => g.id !== id))
    router.refresh()
  }

  function getContentPreview(generation: Generation): string {
    const content = generation.output_content
    
    if (generation.tool_type === "idea" && content.ideas) {
      const ideas = content.ideas as Array<{ title: string }>
      return ideas[0]?.title || "Sin titulo"
    }
    if (generation.tool_type === "hook" && content.hooks) {
      const hooks = content.hooks as Array<{ text: string }>
      return hooks[0]?.text || "Sin contenido"
    }
    if (generation.tool_type === "script" && content.script) {
      const script = content.script as { title: string }
      return script.title || "Sin titulo"
    }
    if (generation.tool_type === "trend" && content.trends) {
      const trends = content.trends as Array<{ trend: string }>
      return trends[0]?.trend || "Sin tendencia"
    }
    
    return "Contenido guardado"
  }

  function getFullContent(generation: Generation): string {
    const content = generation.output_content
    
    if (generation.tool_type === "idea" && content.ideas) {
      const ideas = content.ideas as Array<{ title: string; description: string; hook: string }>
      return ideas.map((i) => `${i.title}\n${i.description}\nHook: ${i.hook}`).join("\n\n---\n\n")
    }
    if (generation.tool_type === "hook" && content.hooks) {
      const hooks = content.hooks as Array<{ text: string }>
      return hooks.map((h) => h.text).join("\n\n")
    }
    if (generation.tool_type === "script" && content.script) {
      const script = content.script as { title: string; hook: string; intro: string; body: string[]; climax: string; cta: string }
      return `${script.title}\n\nHOOK:\n${script.hook}\n\nINTRO:\n${script.intro}\n\nCONTENIDO:\n${script.body?.join("\n")}\n\nCLIMAX:\n${script.climax}\n\nCTA:\n${script.cta}`
    }
    if (generation.tool_type === "trend" && content.trends) {
      const trends = content.trends as Array<{ trend: string; howToUse: string; exampleIdea: string }>
      return trends.map((t) => `${t.trend}\n${t.howToUse}\nIdea: ${t.exampleIdea}`).join("\n\n---\n\n")
    }
    
    return JSON.stringify(content, null, 2)
  }

  function handleCopy(generation: Generation) {
    navigator.clipboard.writeText(getFullContent(generation))
    setCopiedId(generation.id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  if (generations.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
          <History className="h-8 w-8 text-primary" />
        </div>
        <h3 className="mt-4 text-lg font-semibold text-foreground">
          No hay generaciones recientes
        </h3>
        <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
          Tus generaciones apareceran aqui a medida que uses las herramientas
        </p>
      </div>
    )
  }

  // Group by date
  const groupedByDate = generations.reduce((acc, gen) => {
    const date = new Date(gen.created_at).toLocaleDateString("es", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
    if (!acc[date]) acc[date] = []
    acc[date].push(gen)
    return acc
  }, {} as Record<string, Generation[]>)

  return (
    <div className="space-y-8">
      {plan === "free" && (
        <div className="flex items-center justify-between rounded-lg bg-primary/10 p-4">
          <div className="flex items-center gap-3">
            <Crown className="h-5 w-5 text-primary" />
            <p className="text-sm text-foreground">
              El historial esta limitado a 7 dias en el plan gratuito
            </p>
          </div>
          <Button asChild size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90">
            <Link href="/dashboard/upgrade">Actualizar</Link>
          </Button>
        </div>
      )}

      {Object.entries(groupedByDate).map(([date, items]) => (
        <div key={date}>
          <h3 className="mb-4 text-sm font-medium text-muted-foreground capitalize">{date}</h3>
          <div className="space-y-3">
            {items.map((generation) => {
              const Icon = toolIcons[generation.tool_type] || Lightbulb
              const toolName = toolNames[generation.tool_type] || "Generacion"

              return (
                <div
                  key={generation.id}
                  className="glass-card rounded-lg p-4 transition-all hover:border-primary/50"
                >
                  <div className="flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-primary/20">
                        <Icon className="h-4 w-4 text-primary" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium text-foreground">{toolName}</span>
                          {generation.is_favorite && (
                            <Heart className="h-3 w-3 fill-primary text-primary" />
                          )}
                        </div>
                        <p className="truncate text-sm text-muted-foreground">
                          {generation.input_topic}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleToggleFavorite(generation.id, generation.is_favorite)}
                      >
                        <Heart className={`h-4 w-4 ${generation.is_favorite ? "fill-primary text-primary" : ""}`} />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleCopy(generation)}
                      >
                        {copiedId === generation.id ? (
                          <Check className="h-4 w-4 text-green-500" />
                        ) : (
                          <Copy className="h-4 w-4" />
                        )}
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-muted-foreground hover:text-destructive"
                        onClick={() => handleDelete(generation.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <p className="mt-2 line-clamp-1 text-sm text-muted-foreground pl-12">
                    {getContentPreview(generation)}
                  </p>
                </div>
              )
            })}
          </div>
        </div>
      ))}
    </div>
  )
}
