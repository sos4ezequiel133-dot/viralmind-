"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { MessageSquare, Loader2, Sparkles, Heart, Copy, Check } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Hook {
  text: string
  type: string
  emotion: string
  timing: string
}

interface HookGeneratorProps {
  userId: string
  plan: string
  generationsUsed: number
}

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export function HookGenerator({ userId, plan, generationsUsed }: HookGeneratorProps) {
  const [topic, setTopic] = useState("")
  const [hooks, setHooks] = useState<Hook[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<number | null>(null)

  const limit = planLimits[plan]
  const remaining = Math.max(0, limit - generationsUsed)

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault()
    if (!topic.trim()) return

    setLoading(true)
    setError(null)
    setHooks([])

    try {
      const response = await fetch("/api/generate/hooks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, language: "es" }),
      })

      if (response.status === 429) {
        setError("Has alcanzado el limite del plan gratuito.")
        window.location.href = "/dashboard/upgrade"
        return
      }

      if (!response.ok) {
        throw new Error("Error al generar hooks")
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullContent = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          fullContent += decoder.decode(value, { stream: true })
        }

        try {
          const parsed = JSON.parse(fullContent)
          setHooks(parsed.hooks || [])
        } catch {
          setError("Error al procesar la respuesta")
        }
      }
    } catch {
      setError("Error de conexion. Intenta de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  async function handleFavorite(hook: Hook) {
    const supabase = createClient()
    await supabase.from("generations").insert({
      user_id: userId,
      tool_type: "hook",
      input_topic: topic,
      output_content: { hooks: [hook] },
      is_favorite: true,
    })
  }

  function handleCopy(text: string, index: number) {
    navigator.clipboard.writeText(text)
    setCopiedId(index)
    setTimeout(() => setCopiedId(null), 2000)
  }

  return (
    <div className="space-y-8">
      <form onSubmit={handleGenerate} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="topic">Tema del video</Label>
          <div className="flex gap-3">
            <Input
              id="topic"
              placeholder="Ej: 5 errores comunes al invertir, receta de desayuno rapido..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="flex-1 bg-input border-border focus:border-primary"
            />
            <Button
              type="submit"
              disabled={loading || !topic.trim()}
              className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generar
                </>
              )}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {plan === "pro" ? "Generaciones ilimitadas" : `${remaining} generaciones restantes hoy`}
          </p>
        </div>
      </form>

      {error && (
        <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
          {error}
        </div>
      )}

      {hooks.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">
            Hooks generados para &quot;{topic}&quot;
          </h3>
          <div className="space-y-4">
            {hooks.map((hook, index) => (
              <div
                key={index}
                className="glass-card glass-card-hover rounded-xl p-6 transition-all"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-primary" />
                      <span className="text-sm font-medium text-muted-foreground">
                        Hook #{index + 1}
                      </span>
                    </div>
                    <p className="mt-3 text-lg font-medium text-foreground">
                      &quot;{hook.text}&quot;
                    </p>
                    <div className="mt-4 flex flex-wrap gap-2">
                      <span className="rounded-full bg-primary/20 px-3 py-1 text-xs font-medium text-primary">
                        {hook.type}
                      </span>
                      <span className="rounded-full bg-secondary px-3 py-1 text-xs text-secondary-foreground">
                        {hook.emotion}
                      </span>
                      <span className="rounded-full bg-muted px-3 py-1 text-xs text-muted-foreground">
                        {hook.timing}
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9"
                      onClick={() => handleFavorite(hook)}
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-9 w-9"
                      onClick={() => handleCopy(hook.text, index)}
                    >
                      {copiedId === index ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!loading && hooks.length === 0 && !error && (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <MessageSquare className="h-8 w-8 text-primary" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-foreground">
            Crea hooks irresistibles
          </h3>
          <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
            Genera 3 hooks optimizados para capturar la atencion en los primeros 3 segundos
          </p>
        </div>
      )}
    </div>
  )
}
