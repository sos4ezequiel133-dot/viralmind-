"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { createClient } from "@/lib/supabase/client"
import {
  Lightbulb,
  MessageSquare,
  FileText,
  TrendingUp,
  Heart,
  Copy,
  Check,
  Trash2,
} from "lucide-react"

interface Generation {
  id: string
  tool_type: string
  input_topic: string
  output_content: Record<string, unknown>
  created_at: string
}

interface FavoritesListProps {
  favorites: Generation[]
}

const toolIcons: Record<string, React.ElementType> = {
  idea: Lightbulb,
  hook: MessageSquare,
  script: FileText,
  trend: TrendingUp,
}

const toolNames: Record<string, string> = {
  idea: "Idea",
  hook: "Hook",
  script: "Guion",
  trend: "Tendencia",
}

export function FavoritesList({ favorites: initialFavorites }: FavoritesListProps) {
  const [favorites, setFavorites] = useState(initialFavorites)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const router = useRouter()

  async function handleRemove(id: string) {
    const supabase = createClient()
    await supabase
      .from("generations")
      .update({ is_favorite: false })
      .eq("id", id)
    
    setFavorites(favorites.filter((f) => f.id !== id))
    router.refresh()
  }

  function getContentPreview(generation: Generation): string {
    const content = generation.output_content
    
    if (generation.tool_type === "idea" && content.ideas) {
      const ideas = content.ideas as Array<{ title: string }>
      return ideas[0]?.title || "Sin titulo"
    }
    if (generation.tool_type === "hook" && content.hooks) {
      const hooks = content.hooks as Array<{ text: string }>
      return hooks[0]?.text || "Sin contenido"
    }
    if (generation.tool_type === "script" && content.script) {
      const script = content.script as { title: string }
      return script.title || "Sin titulo"
    }
    if (generation.tool_type === "trend" && content.trends) {
      const trends = content.trends as Array<{ trend: string }>
      return trends[0]?.trend || "Sin tendencia"
    }
    
    return "Contenido guardado"
  }

  function getFullContent(generation: Generation): string {
    const content = generation.output_content
    
    if (generation.tool_type === "idea" && content.ideas) {
      const ideas = content.ideas as Array<{ title: string; description: string; hook: string }>
      return ideas.map((i) => `${i.title}\n${i.description}\nHook: ${i.hook}`).join("\n\n---\n\n")
    }
    if (generation.tool_type === "hook" && content.hooks) {
      const hooks = content.hooks as Array<{ text: string }>
      return hooks.map((h) => h.text).join("\n\n")
    }
    if (generation.tool_type === "script" && content.script) {
      const script = content.script as { title: string; hook: string; intro: string; body: string[]; climax: string; cta: string }
      return `${script.title}\n\nHOOK:\n${script.hook}\n\nINTRO:\n${script.intro}\n\nCONTENIDO:\n${script.body?.join("\n")}\n\nCLIMAX:\n${script.climax}\n\nCTA:\n${script.cta}`
    }
    if (generation.tool_type === "trend" && content.trends) {
      const trends = content.trends as Array<{ trend: string; howToUse: string; exampleIdea: string }>
      return trends.map((t) => `${t.trend}\n${t.howToUse}\nIdea: ${t.exampleIdea}`).join("\n\n---\n\n")
    }
    
    return JSON.stringify(content, null, 2)
  }

  function handleCopy(generation: Generation) {
    navigator.clipboard.writeText(getFullContent(generation))
    setCopiedId(generation.id)
    setTimeout(() => setCopiedId(null), 2000)
  }

  if (favorites.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
        <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
          <Heart className="h-8 w-8 text-primary" />
        </div>
        <h3 className="mt-4 text-lg font-semibold text-foreground">
          No tienes favoritos aun
        </h3>
        <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
          Guarda tus mejores generaciones haciendo clic en el icono de corazon
        </p>
      </div>
    )
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {favorites.map((generation) => {
        const Icon = toolIcons[generation.tool_type] || Lightbulb
        const toolName = toolNames[generation.tool_type] || "Generacion"

        return (
          <div
            key={generation.id}
            className="glass-card glass-card-hover rounded-xl p-5 transition-all"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <span className="text-sm font-medium text-foreground">{toolName}</span>
                  <p className="text-xs text-muted-foreground">
                    {new Date(generation.created_at).toLocaleDateString("es")}
                  </p>
                </div>
              </div>
              <Heart className="h-4 w-4 fill-primary text-primary" />
            </div>

            <div className="mt-4">
              <p className="text-xs text-muted-foreground">Tema:</p>
              <p className="text-sm font-medium text-foreground">{generation.input_topic}</p>
            </div>

            <div className="mt-3 rounded-lg bg-muted/30 p-3">
              <p className="line-clamp-2 text-sm text-foreground">
                {getContentPreview(generation)}
              </p>
            </div>

            <div className="mt-4 flex justify-end gap-2">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8 text-muted-foreground hover:text-destructive"
                onClick={() => handleRemove(generation.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => handleCopy(generation)}
              >
                {copiedId === generation.id ? (
                  <Check className="h-4 w-4 text-green-500" />
                ) : (
                  <Copy className="h-4 w-4" />
                )}
              </Button>
            </div>
          </div>
        )
      })}
    </div>
  )
}
