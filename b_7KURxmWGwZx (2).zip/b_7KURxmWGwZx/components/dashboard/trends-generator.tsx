"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { TrendingUp, Loader2, Sparkles, Heart, Copy, Check } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Trend {
  trend: string
  platform: string
  category: string
  howToUse: string
  exampleIdea: string
  viralPotential: number
}

interface TrendsGeneratorProps {
  userId: string
  plan: string
  generationsUsed: number
}

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export function TrendsGenerator({ userId, plan, generationsUsed }: TrendsGeneratorProps) {
  const [niche, setNiche] = useState("")
  const [trends, setTrends] = useState<Trend[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<number | null>(null)

  const limit = planLimits[plan]
  const remaining = Math.max(0, limit - generationsUsed)

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault()
    if (!niche.trim()) return

    setLoading(true)
    setError(null)
    setTrends([])

    try {
      const response = await fetch("/api/generate/trends", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ niche, language: "es" }),
      })

      if (response.status === 429) {
        setError("Has alcanzado el limite del plan gratuito.")
        window.location.href = "/dashboard/upgrade"
        return
      }

      if (!response.ok) {
        throw new Error("Error al obtener tendencias")
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullContent = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          fullContent += decoder.decode(value, { stream: true })
        }

        try {
          const parsed = JSON.parse(fullContent)
          setTrends(parsed.trends || [])
        } catch {
          setError("Error al procesar la respuesta")
        }
      }
    } catch {
      setError("Error de conexion. Intenta de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  async function handleFavorite(trend: Trend) {
    const supabase = createClient()
    await supabase.from("generations").insert({
      user_id: userId,
      tool_type: "trend",
      input_topic: niche,
      output_content: { trends: [trend] },
      is_favorite: true,
    })
  }

  function handleCopy(trend: Trend, index: number) {
    const text = `${trend.trend}\n\nPlataforma: ${trend.platform}\nCategoria: ${trend.category}\n\nComo usarla: ${trend.howToUse}\n\nIdea de ejemplo: ${trend.exampleIdea}`
    navigator.clipboard.writeText(text)
    setCopiedId(index)
    setTimeout(() => setCopiedId(null), 2000)
  }

  return (
    <div className="space-y-8">
      <form onSubmit={handleGenerate} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="niche">Tu nicho</Label>
          <div className="flex gap-3">
            <Input
              id="niche"
              placeholder="Ej: fitness, belleza, emprendimiento, gaming..."
              value={niche}
              onChange={(e) => setNiche(e.target.value)}
              className="flex-1 bg-input border-border focus:border-primary"
            />
            <Button
              type="submit"
              disabled={loading || !niche.trim()}
              className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Analizar
                </>
              )}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {plan === "pro" ? "Generaciones ilimitadas" : `${remaining} generaciones restantes hoy`}
          </p>
        </div>
      </form>

      {error && (
        <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
          {error}
        </div>
      )}

      {trends.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">
            Tendencias para &quot;{niche}&quot;
          </h3>
          <div className="grid gap-4 lg:grid-cols-2">
            {trends.map((trend, index) => (
              <div
                key={index}
                className="glass-card glass-card-hover rounded-xl p-5 transition-all"
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20">
                      <TrendingUp className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground">{trend.trend}</h4>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="text-xs text-muted-foreground">{trend.platform}</span>
                        <span className="text-muted-foreground">•</span>
                        <span className="text-xs text-muted-foreground">{trend.category}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-1 rounded-full bg-primary/20 px-2 py-0.5">
                    <span className="text-xs font-medium text-primary">{trend.viralPotential}/10</span>
                  </div>
                </div>

                <div className="mt-4 space-y-3">
                  <div>
                    <p className="text-xs font-medium text-muted-foreground">Como aplicarla:</p>
                    <p className="mt-1 text-sm text-foreground">{trend.howToUse}</p>
                  </div>
                  <div className="rounded-lg bg-muted/30 p-3">
                    <p className="text-xs font-medium text-muted-foreground">Idea de ejemplo:</p>
                    <p className="mt-1 text-sm text-foreground">{trend.exampleIdea}</p>
                  </div>
                </div>

                <div className="mt-4 flex justify-end gap-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleFavorite(trend)}
                  >
                    <Heart className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => handleCopy(trend, index)}
                  >
                    {copiedId === index ? (
                      <Check className="h-4 w-4 text-green-500" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {!loading && trends.length === 0 && !error && (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <TrendingUp className="h-8 w-8 text-primary" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-foreground">
            Analiza tendencias de tu nicho
          </h3>
          <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
            Descubre las tendencias actuales y aprende como aplicarlas a tu contenido
          </p>
        </div>
      )}
    </div>
  )
}
