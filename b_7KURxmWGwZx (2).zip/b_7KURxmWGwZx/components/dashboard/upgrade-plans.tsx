"use client"

import { Button } from "@/components/ui/button"
import { Check, Zap, Crown } from "lucide-react"

interface UpgradePlansProps {
  currentPlan: string
}

const plans = [
  {
    id: "free",
    name: "Gratis",
    price: "$0",
    period: "/mes",
    description: "Perfecto para probar",
    features: [
      "3 generaciones gratuitas",
      "Generador de ideas",
      "Creador de hooks",
      "Historial de 7 dias",
    ],
    popular: false,
  },
  {
    id: "starter",
    name: "Starter",
    price: "$9",
    period: "/mes",
    description: "Para creadores serios",
    features: [
      "50 generaciones por mes",
      "Todas las herramientas",
      "Script Studio completo",
      "Tendencias en tiempo real",
      "Favoritos ilimitados",
      "Exportar guiones",
      "Historial completo",
    ],
    popular: true,
  },
  {
    id: "pro",
    name: "Pro",
    price: "$19",
    period: "/mes",
    description: "Para profesionales",
    features: [
      "Generaciones ilimitadas",
      "Velocidad IA prioritaria",
      "Exportar contenido",
      "Content Studio completo",
      "Soporte prioritario",
      "Todas las funciones",
    ],
    popular: false,
  },
]

export function UpgradePlans({ currentPlan }: UpgradePlansProps) {
  function handleUpgrade(planId: string) {
    // In a real app, this would redirect to Stripe checkout
    alert(`Redirigiendo a checkout para plan ${planId}...`)
  }

  return (
    <div className="grid gap-6 lg:grid-cols-3">
      {plans.map((plan) => {
        const isCurrent = plan.id === currentPlan
        const isUpgrade = plans.findIndex((p) => p.id === plan.id) > plans.findIndex((p) => p.id === currentPlan)

        return (
          <div
            key={plan.id}
            className={`relative rounded-2xl p-6 ${
              plan.popular
                ? "glass-card neon-border"
                : "glass-card border border-border"
            }`}
          >
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                <div className="inline-flex items-center gap-1 rounded-full bg-primary px-3 py-1 text-xs font-medium text-primary-foreground">
                  <Zap className="h-3 w-3" />
                  Mas Popular
                </div>
              </div>
            )}

            {isCurrent && (
              <div className="absolute -top-3 right-4">
                <div className="inline-flex items-center gap-1 rounded-full bg-secondary px-3 py-1 text-xs font-medium text-secondary-foreground">
                  Plan Actual
                </div>
              </div>
            )}

            <div className="text-center">
              <div className="flex items-center justify-center gap-2">
                {plan.id === "pro" && <Crown className="h-5 w-5 text-primary" />}
                <h3 className="text-xl font-semibold text-foreground">{plan.name}</h3>
              </div>
              <div className="mt-4 flex items-baseline justify-center gap-1">
                <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                <span className="text-muted-foreground">{plan.period}</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>
            </div>

            <ul className="mt-6 space-y-3">
              {plan.features.map((feature) => (
                <li key={feature} className="flex items-center gap-3">
                  <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/20">
                    <Check className="h-3 w-3 text-primary" />
                  </div>
                  <span className="text-sm text-muted-foreground">{feature}</span>
                </li>
              ))}
            </ul>

            <div className="mt-6">
              {isCurrent ? (
                <Button disabled className="w-full" variant="secondary">
                  Plan Actual
                </Button>
              ) : isUpgrade ? (
                <Button
                  onClick={() => handleUpgrade(plan.id)}
                  className={`w-full ${
                    plan.popular
                      ? "bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
                      : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                  }`}
                >
                  Actualizar a {plan.name}
                </Button>
              ) : (
                <Button disabled variant="outline" className="w-full">
                  Downgrade no disponible
                </Button>
              )}
            </div>
          </div>
        )
      })}
    </div>
  )
}
