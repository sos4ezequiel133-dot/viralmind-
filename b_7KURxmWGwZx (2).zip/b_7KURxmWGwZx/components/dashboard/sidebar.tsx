"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { User } from "@supabase/supabase-js"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import {
  Zap,
  Lightbulb,
  MessageSquare,
  FileText,
  TrendingUp,
  Heart,
  History,
  Settings,
  Crown,
  X,
  PenTool,
} from "lucide-react"
import { useSidebarStore } from "@/lib/stores/sidebar-store"

interface Profile {
  id: string
  email: string | null
  full_name: string | null
  plan: string
  generations_used: number
}

interface DashboardSidebarProps {
  user: User
  profile: Profile | null
}

const navigation = [
  { name: "Ideas", href: "/dashboard", icon: Lightbulb },
  { name: "Hooks", href: "/dashboard/hooks", icon: MessageSquare },
  { name: "Script Studio", href: "/dashboard/scripts", icon: FileText },
  { name: "Tendencias", href: "/dashboard/trends", icon: TrendingUp },
  { name: "Content Studio", href: "/dashboard/studio", icon: PenTool },
  { name: "Favoritos", href: "/dashboard/favorites", icon: Heart },
  { name: "Historial", href: "/dashboard/history", icon: History },
]

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export function DashboardSidebar({ profile }: DashboardSidebarProps) {
  const pathname = usePathname()
  const { isOpen, close } = useSidebarStore()
  const plan = profile?.plan || "free"
  const used = profile?.generations_used || 0
  const limit = planLimits[plan]
  const percentage = Math.min((used / limit) * 100, 100)

  return (
    <>
      {/* Mobile overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 z-40 bg-background/80 backdrop-blur-sm lg:hidden"
          onClick={close}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 flex w-72 flex-col border-r border-border bg-sidebar transition-transform duration-300 lg:translate-x-0",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Header */}
        <div className="flex h-16 items-center justify-between border-b border-sidebar-border px-6">
          <Link href="/dashboard" className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 neon-border">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <span className="text-xl font-bold text-sidebar-foreground">
              Viral<span className="text-primary">Mind</span>
            </span>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={close}
          >
            <X className="h-5 w-5" />
          </Button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 p-4">
          {navigation.map((item) => {
            const isActive = pathname === item.href
            return (
              <Link
                key={item.name}
                href={item.href}
                onClick={close}
                className={cn(
                  "flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
                  isActive
                    ? "bg-sidebar-accent text-primary neon-glow"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                )}
              >
                <item.icon className={cn("h-5 w-5", isActive && "text-primary")} />
                {item.name}
              </Link>
            )
          })}
        </nav>

        {/* Usage & Plan */}
        <div className="border-t border-sidebar-border p-4">
          {/* Usage meter */}
          <div className="mb-4 rounded-lg bg-sidebar-accent p-4">
            <div className="flex items-center justify-between text-sm">
              <span className="text-sidebar-foreground/70">Generaciones hoy</span>
              <span className="font-medium text-sidebar-foreground">
                {used}/{plan === "pro" ? "∞" : limit}
              </span>
            </div>
            <div className="mt-2 h-2 overflow-hidden rounded-full bg-sidebar-border">
              <div
                className="h-full bg-primary transition-all"
                style={{ width: `${plan === "pro" ? 10 : percentage}%` }}
              />
            </div>
          </div>

          {/* Upgrade button for free users */}
          {plan === "free" && (
            <Button
              asChild
              className="w-full bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
            >
              <Link href="/dashboard/upgrade">
                <Crown className="mr-2 h-4 w-4" />
                Actualizar Plan
              </Link>
            </Button>
          )}

          {/* Settings */}
          <Link
            href="/dashboard/settings"
            className={cn(
              "mt-4 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
              pathname === "/dashboard/settings"
                ? "bg-sidebar-accent text-primary"
                : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
            )}
          >
            <Settings className="h-5 w-5" />
            Configuracion
          </Link>
        </div>
      </aside>
    </>
  )
}
