"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { 
  Plus, 
  Save, 
  Trash2, 
  FileText, 
  FolderOpen,
  Download,
  Loader2,
  Check
} from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Project {
  id: string
  title: string
  content: string
  is_draft: boolean
  created_at: string
  updated_at: string
}

export function ContentStudio() {
  const [projects, setProjects] = useState<Project[]>([])
  const [activeProject, setActiveProject] = useState<Project | null>(null)
  const [title, setTitle] = useState("")
  const [content, setContent] = useState("")
  const [loading, setLoading] = useState(false)
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    loadProjects()
  }, [])

  async function loadProjects() {
    setLoading(true)
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (user) {
      const { data } = await supabase
        .from("scripts")
        .select("*")
        .eq("user_id", user.id)
        .order("updated_at", { ascending: false })
      
      if (data) {
        setProjects(data)
      }
    }
    setLoading(false)
  }

  async function createNewProject() {
    const supabase = createClient()
    const { data: { user } } = await supabase.auth.getUser()
    
    if (!user) return

    const newProject = {
      user_id: user.id,
      title: "Nuevo proyecto",
      content: "",
      is_draft: true,
    }

    const { data, error } = await supabase
      .from("scripts")
      .insert(newProject)
      .select()
      .single()

    if (data && !error) {
      setProjects([data, ...projects])
      setActiveProject(data)
      setTitle(data.title)
      setContent(data.content)
    }
  }

  async function saveProject() {
    if (!activeProject) return
    
    setSaving(true)
    const supabase = createClient()
    
    const { error } = await supabase
      .from("scripts")
      .update({ 
        title, 
        content, 
        updated_at: new Date().toISOString() 
      })
      .eq("id", activeProject.id)

    if (!error) {
      setProjects(projects.map(p => 
        p.id === activeProject.id 
          ? { ...p, title, content, updated_at: new Date().toISOString() }
          : p
      ))
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    }
    setSaving(false)
  }

  async function deleteProject(id: string) {
    const supabase = createClient()
    await supabase.from("scripts").delete().eq("id", id)
    
    setProjects(projects.filter(p => p.id !== id))
    if (activeProject?.id === id) {
      setActiveProject(null)
      setTitle("")
      setContent("")
    }
  }

  function selectProject(project: Project) {
    setActiveProject(project)
    setTitle(project.title)
    setContent(project.content)
  }

  function exportToTxt() {
    if (!activeProject) return
    
    const blob = new Blob([`${title}\n\n${content}`], { type: "text/plain" })
    const url = URL.createObjectURL(blob)
    const a = document.createElement("a")
    a.href = url
    a.download = `${title.replace(/\s+/g, "_")}.txt`
    a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div className="grid gap-6 lg:grid-cols-4">
      {/* Sidebar - Projects list */}
      <div className="lg:col-span-1">
        <div className="glass-card rounded-xl p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-foreground flex items-center gap-2">
              <FolderOpen className="h-4 w-4" />
              Proyectos
            </h3>
            <Button
              size="sm"
              variant="ghost"
              onClick={createNewProject}
              className="h-8 w-8 p-0"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
            </div>
          ) : projects.length === 0 ? (
            <div className="text-center py-8">
              <FileText className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
              <p className="text-sm text-muted-foreground">
                No tienes proyectos aun
              </p>
              <Button
                size="sm"
                className="mt-4"
                onClick={createNewProject}
              >
                <Plus className="h-4 w-4 mr-2" />
                Crear proyecto
              </Button>
            </div>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {projects.map((project) => (
                <div
                  key={project.id}
                  onClick={() => selectProject(project)}
                  className={`group flex items-center justify-between rounded-lg p-3 cursor-pointer transition-all ${
                    activeProject?.id === project.id
                      ? "bg-primary/20 border border-primary"
                      : "hover:bg-muted/50"
                  }`}
                >
                  <div className="flex items-center gap-2 min-w-0">
                    <FileText className="h-4 w-4 text-muted-foreground shrink-0" />
                    <span className="text-sm truncate">{project.title}</span>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation()
                      deleteProject(project.id)
                    }}
                    className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100"
                  >
                    <Trash2 className="h-3 w-3 text-destructive" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Main editor */}
      <div className="lg:col-span-3">
        <div className="glass-card rounded-xl p-6">
          {activeProject ? (
            <div className="space-y-4">
              {/* Title input */}
              <div className="space-y-2">
                <Label htmlFor="title">Titulo</Label>
                <Input
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="Titulo del proyecto"
                  className="bg-input border-border focus:border-primary text-lg font-semibold"
                  dir="ltr"
                />
              </div>

              {/* Content textarea */}
              <div className="space-y-2">
                <Label htmlFor="content">Contenido</Label>
                <textarea
                  id="content"
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Escribe tu guion, ideas o contenido aqui..."
                  className="w-full h-96 rounded-lg bg-input border border-border p-4 text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary resize-none"
                  dir="ltr"
                  style={{ textAlign: "left", direction: "ltr" }}
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-between pt-4 border-t border-border">
                <p className="text-xs text-muted-foreground">
                  Ultima edicion: {new Date(activeProject.updated_at).toLocaleString("es")}
                </p>
                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={exportToTxt}
                    className="gap-2"
                  >
                    <Download className="h-4 w-4" />
                    Exportar TXT
                  </Button>
                  <Button
                    size="sm"
                    onClick={saveProject}
                    disabled={saving}
                    className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90"
                  >
                    {saving ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : saved ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    {saved ? "Guardado" : "Guardar"}
                  </Button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
                <FileText className="h-8 w-8 text-primary" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">
                Selecciona o crea un proyecto
              </h3>
              <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
                Organiza tus guiones, ideas y contenido en proyectos. Edita y exporta cuando estes listo.
              </p>
              <Button
                className="mt-6 gap-2 bg-primary text-primary-foreground"
                onClick={createNewProject}
              >
                <Plus className="h-4 w-4" />
                Crear nuevo proyecto
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
