"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Lightbulb, Loader2, Sparkles, Heart, Copy, Check } from "lucide-react"
import { createClient } from "@/lib/supabase/client"

interface Idea {
  title: string
  description: string
  hook: string
  format: string
  viralScore: number
}

interface IdeaGeneratorProps {
  userId: string
  plan: string
  generationsUsed: number
}

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export function IdeaGenerator({ userId, plan, generationsUsed }: IdeaGeneratorProps) {
  const [topic, setTopic] = useState("")
  const [ideas, setIdeas] = useState<Idea[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [copiedId, setCopiedId] = useState<number | null>(null)

  const limit = planLimits[plan]
  const remaining = Math.max(0, limit - generationsUsed)

  async function handleGenerate(e: React.FormEvent) {
    e.preventDefault()
    if (!topic.trim()) return

    setLoading(true)
    setError(null)
    setIdeas([])

    try {
      const response = await fetch("/api/generate/ideas", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, language: "es" }),
      })

      if (response.status === 429) {
        setError("Has alcanzado el limite del plan gratuito.")
        window.location.href = "/dashboard/upgrade"
        return
      }

      if (!response.ok) {
        throw new Error("Error al generar ideas")
      }

      const reader = response.body?.getReader()
      const decoder = new TextDecoder()
      let fullContent = ""

      if (reader) {
        while (true) {
          const { done, value } = await reader.read()
          if (done) break
          fullContent += decoder.decode(value, { stream: true })
        }

        try {
          const parsed = JSON.parse(fullContent)
          setIdeas(parsed.ideas || [])
        } catch {
          setError("Error al procesar la respuesta")
        }
      }
    } catch {
      setError("Error de conexion. Intenta de nuevo.")
    } finally {
      setLoading(false)
    }
  }

  async function handleFavorite(idea: Idea, index: number) {
    const supabase = createClient()
    await supabase.from("generations").insert({
      user_id: userId,
      tool_type: "idea",
      input_topic: topic,
      output_content: { ideas: [idea] },
      is_favorite: true,
    })
    // Visual feedback could be added here
  }

  function handleCopy(text: string, index: number) {
    navigator.clipboard.writeText(text)
    setCopiedId(index)
    setTimeout(() => setCopiedId(null), 2000)
  }

  return (
    <div className="space-y-8">
      {/* Generator form */}
      <form onSubmit={handleGenerate} className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="topic">Tu nicho o tema</Label>
          <div className="flex gap-3">
            <Input
              id="topic"
              placeholder="Ej: fitness, cocina saludable, finanzas personales..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              className="flex-1 bg-input border-border focus:border-primary"
            />
            <Button
              type="submit"
              disabled={loading || !topic.trim()}
              className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <>
                  <Sparkles className="mr-2 h-4 w-4" />
                  Generar
                </>
              )}
            </Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {plan === "pro" ? "Generaciones ilimitadas" : `${remaining} generaciones restantes hoy`}
          </p>
        </div>
      </form>

      {error && (
        <div className="rounded-lg bg-destructive/10 p-4 text-sm text-destructive">
          {error}
        </div>
      )}

      {/* Results */}
      {ideas.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold text-foreground">
            Ideas generadas para &quot;{topic}&quot;
          </h3>
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {ideas.map((idea, index) => (
              <div
                key={index}
                className="glass-card glass-card-hover rounded-xl p-5 transition-all"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20">
                    <Lightbulb className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="rounded-full bg-primary/20 px-2 py-0.5 text-xs font-medium text-primary">
                      {idea.viralScore}/10
                    </span>
                  </div>
                </div>

                <h4 className="mt-4 font-semibold text-foreground">{idea.title}</h4>
                <p className="mt-2 text-sm text-muted-foreground">{idea.description}</p>

                <div className="mt-4 rounded-lg bg-muted/30 p-3">
                  <p className="text-xs font-medium text-muted-foreground">Hook sugerido:</p>
                  <p className="mt-1 text-sm text-foreground">&quot;{idea.hook}&quot;</p>
                </div>

                <div className="mt-4 flex items-center justify-between">
                  <span className="rounded-full bg-secondary px-2 py-1 text-xs text-secondary-foreground">
                    {idea.format}
                  </span>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleFavorite(idea, index)}
                    >
                      <Heart className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => handleCopy(`${idea.title}\n\n${idea.description}\n\nHook: ${idea.hook}`, index)}
                    >
                      {copiedId === index ? (
                        <Check className="h-4 w-4 text-green-500" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Empty state */}
      {!loading && ideas.length === 0 && !error && (
        <div className="flex flex-col items-center justify-center rounded-xl border border-dashed border-border py-16">
          <div className="flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
            <Lightbulb className="h-8 w-8 text-primary" />
          </div>
          <h3 className="mt-4 text-lg font-semibold text-foreground">
            Genera tus primeras ideas
          </h3>
          <p className="mt-2 max-w-sm text-center text-sm text-muted-foreground">
            Ingresa tu nicho o tema y recibe 5 ideas virales optimizadas para TikTok, Reels y Shorts
          </p>
        </div>
      )}
    </div>
  )
}
