"use client"

import { Lightbulb, MessageSquare, FileText, TrendingUp, Heart, Download } from "lucide-react"

const features = [
  {
    icon: Lightbulb,
    title: "Generador de Ideas",
    description: "Recibe 5 ideas virales personalizadas para tu nicho. Perfectas para TikTok, Reels e YouTube Shorts.",
  },
  {
    icon: MessageSquare,
    title: "Creador de Hooks",
    description: "Genera 3 hooks irresistibles que capturan la atencion en los primeros 3 segundos.",
  },
  {
    icon: FileText,
    title: "Script Studio",
    description: "Crea guiones completos optimizados para formato vertical con estructura probada.",
  },
  {
    icon: TrendingUp,
    title: "Tendencias en Tiempo Real",
    description: "Descubre las tendencias actuales de tu nicho con datos en tiempo real.",
  },
  {
    icon: Heart,
    title: "Favoritos",
    description: "Guarda tus mejores generaciones y accede a ellas cuando las necesites.",
  },
  {
    icon: Download,
    title: "Exportar y Compartir",
    description: "Descarga tus guiones en TXT o copialos directamente al portapapeles.",
  },
]

export function LandingFeatures() {
  return (
    <section id="features" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Todo lo que necesitas para{" "}
            <span className="text-primary">crear contenido viral</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            Herramientas potentes impulsadas por IA para transformar tu proceso creativo
          </p>
        </div>

        <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="glass-card glass-card-hover group rounded-xl p-6 transition-all duration-300"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 transition-all group-hover:bg-primary/20 group-hover:neon-glow">
                <feature.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="mt-4 text-lg font-semibold text-foreground">{feature.title}</h3>
              <p className="mt-2 text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
