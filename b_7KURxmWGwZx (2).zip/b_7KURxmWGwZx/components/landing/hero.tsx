"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { ArrowRight, Sparkles, TrendingUp, Zap, Play } from "lucide-react"

export function LandingHero() {
  return (
    <section className="relative overflow-hidden pt-32 pb-20 sm:pt-40 sm:pb-32">
      {/* Animated background elements */}
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl animate-pulse-glow" />
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          {/* Badge */}
          <div className="mb-8 inline-flex items-center gap-2 rounded-full border border-primary/30 bg-primary/10 px-4 py-2">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-primary">Potenciado por IA Avanzada</span>
          </div>

          {/* Main headline */}
          <h1 className="mx-auto max-w-4xl text-balance text-4xl font-bold tracking-tight text-foreground sm:text-6xl lg:text-7xl">
            Genera Contenido{" "}
            <span className="neon-text">Viral</span>{" "}
            en Segundos
          </h1>

          {/* Subheadline */}
          <p className="mx-auto mt-6 max-w-2xl text-pretty text-lg text-muted-foreground sm:text-xl">
            Crea ideas irresistibles, hooks que atrapan y guiones optimizados para TikTok, 
            Reels e YouTube Shorts. Tu asistente de IA para dominar las redes sociales.
          </p>

          {/* CTA buttons */}
          <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
            <Button size="lg" asChild className="h-12 px-8 text-base bg-primary text-primary-foreground hover:bg-primary/90 neon-glow">
              <Link href="/auth/sign-up">
                Comenzar Gratis
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button size="lg" variant="outline" className="h-12 px-8 text-base border-border hover:border-primary hover:text-primary">
              <Play className="mr-2 h-4 w-4" />
              Ver Demo
            </Button>
          </div>

          {/* Stats */}
          <div className="mt-16 grid grid-cols-3 gap-8 sm:gap-16">
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-2 text-2xl font-bold text-foreground sm:text-3xl">
                <TrendingUp className="h-6 w-6 text-primary" />
                10K+
              </div>
              <p className="mt-1 text-sm text-muted-foreground">Creadores Activos</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-2 text-2xl font-bold text-foreground sm:text-3xl">
                <Zap className="h-6 w-6 text-primary" />
                500K+
              </div>
              <p className="mt-1 text-sm text-muted-foreground">Ideas Generadas</p>
            </div>
            <div className="flex flex-col items-center">
              <div className="flex items-center gap-2 text-2xl font-bold text-foreground sm:text-3xl">
                <Sparkles className="h-6 w-6 text-primary" />
                98%
              </div>
              <p className="mt-1 text-sm text-muted-foreground">Satisfaccion</p>
            </div>
          </div>
        </div>

        {/* Preview mockup */}
        <div className="mt-20 animate-float">
          <div className="glass-card glass-card-hover mx-auto max-w-4xl overflow-hidden rounded-2xl p-1">
            <div className="rounded-xl bg-card p-6">
              <div className="flex items-center gap-3 border-b border-border pb-4">
                <div className="h-3 w-3 rounded-full bg-destructive/50" />
                <div className="h-3 w-3 rounded-full bg-yellow-500/50" />
                <div className="h-3 w-3 rounded-full bg-green-500/50" />
                <span className="ml-4 text-sm text-muted-foreground">ViralMind Dashboard</span>
              </div>
              <div className="mt-6 space-y-4">
                <div className="flex items-center gap-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <Sparkles className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="h-4 w-3/4 rounded bg-muted" />
                    <div className="mt-2 h-3 w-1/2 rounded bg-muted/50" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="rounded-lg bg-muted/30 p-4">
                    <div className="h-3 w-1/3 rounded bg-primary/50" />
                    <div className="mt-3 h-2 w-full rounded bg-muted" />
                    <div className="mt-2 h-2 w-4/5 rounded bg-muted" />
                  </div>
                  <div className="rounded-lg bg-muted/30 p-4">
                    <div className="h-3 w-1/3 rounded bg-primary/50" />
                    <div className="mt-3 h-2 w-full rounded bg-muted" />
                    <div className="mt-2 h-2 w-3/5 rounded bg-muted" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
