"use client"

import Link from "next/link"
import { Zap } from "lucide-react"

export function LandingFooter() {
  return (
    <footer className="border-t border-border bg-card/50">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="flex flex-col items-center justify-between gap-6 sm:flex-row">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10">
              <Zap className="h-4 w-4 text-primary" />
            </div>
            <span className="text-lg font-bold text-foreground">
              Viral<span className="text-primary">Mind</span>
            </span>
          </Link>

          <nav className="flex flex-wrap items-center justify-center gap-6">
            <Link href="#features" className="text-sm text-muted-foreground hover:text-primary">
              Funciones
            </Link>
            <Link href="#pricing" className="text-sm text-muted-foreground hover:text-primary">
              Precios
            </Link>
            <Link href="/terms" className="text-sm text-muted-foreground hover:text-primary">
              Terminos
            </Link>
            <Link href="/privacy" className="text-sm text-muted-foreground hover:text-primary">
              Privacidad
            </Link>
          </nav>

          <p className="text-sm text-muted-foreground">
            &copy; {new Date().getFullYear()} ViralMind. Todos los derechos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
