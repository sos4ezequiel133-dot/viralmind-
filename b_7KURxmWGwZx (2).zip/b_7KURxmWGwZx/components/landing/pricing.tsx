"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Check, Zap } from "lucide-react"

const plans = [
  {
    name: "Gratis",
    price: "$0",
    period: "/mes",
    description: "Perfecto para probar la plataforma",
    features: [
      "3 generaciones gratuitas",
      "Generador de ideas",
      "Creador de hooks",
      "Historial de 7 dias",
    ],
    cta: "Comenzar Gratis",
    href: "/auth/sign-up",
    popular: false,
  },
  {
    name: "Starter",
    price: "$9",
    period: "/mes",
    description: "Para creadores que quieren escalar su contenido",
    features: [
      "50 generaciones por mes",
      "Todas las herramientas",
      "Script Studio completo",
      "Tendencias en tiempo real",
      "Favoritos ilimitados",
      "Exportar guiones",
    ],
    cta: "Comenzar con Starter",
    href: "/auth/sign-up?plan=starter",
    popular: true,
  },
  {
    name: "Pro",
    price: "$19",
    period: "/mes",
    description: "Para profesionales y agencias",
    features: [
      "Generaciones ilimitadas",
      "Velocidad IA prioritaria",
      "Exportar contenido",
      "Soporte prioritario",
      "Content Studio completo",
      "Todas las funciones",
    ],
    cta: "Comenzar con Pro",
    href: "/auth/sign-up?plan=pro",
    popular: false,
  },
]

export function LandingPricing() {
  return (
    <section id="pricing" className="relative py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
            Planes simples,{" "}
            <span className="text-primary">resultados extraordinarios</span>
          </h2>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
            Elige el plan perfecto para tu nivel de creacion de contenido
          </p>
        </div>

        <div className="mt-16 grid gap-8 lg:grid-cols-3">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`relative rounded-2xl p-8 ${
                plan.popular
                  ? "glass-card neon-border"
                  : "glass-card border border-border"
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="inline-flex items-center gap-1 rounded-full bg-primary px-4 py-1 text-sm font-medium text-primary-foreground">
                    <Zap className="h-3.5 w-3.5" />
                    Mas Popular
                  </div>
                </div>
              )}

              <div className="text-center">
                <h3 className="text-xl font-semibold text-foreground">{plan.name}</h3>
                <div className="mt-4 flex items-baseline justify-center gap-1">
                  <span className="text-4xl font-bold text-foreground">{plan.price}</span>
                  <span className="text-muted-foreground">{plan.period}</span>
                </div>
                <p className="mt-2 text-sm text-muted-foreground">{plan.description}</p>
              </div>

              <ul className="mt-8 space-y-4">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-3">
                    <div className="flex h-5 w-5 items-center justify-center rounded-full bg-primary/20">
                      <Check className="h-3 w-3 text-primary" />
                    </div>
                    <span className="text-sm text-muted-foreground">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                asChild
                className={`mt-8 w-full ${
                  plan.popular
                    ? "bg-primary text-primary-foreground hover:bg-primary/90 neon-glow"
                    : "bg-secondary text-secondary-foreground hover:bg-secondary/80"
                }`}
              >
                <Link href={plan.href}>{plan.cta}</Link>
              </Button>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
