"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Zap } from "lucide-react"

export function LandingNav() {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border/50 bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 neon-border">
            <Zap className="h-5 w-5 text-primary" />
          </div>
          <span className="text-xl font-bold text-foreground">
            Viral<span className="text-primary">Mind</span>
          </span>
        </Link>

        <div className="hidden items-center gap-8 md:flex">
          <Link href="#features" className="text-sm text-muted-foreground transition-colors hover:text-primary">
            Funciones
          </Link>
          <Link href="#pricing" className="text-sm text-muted-foreground transition-colors hover:text-primary">
            Precios
          </Link>
        </div>

        <div className="flex items-center gap-3">
          <Button variant="ghost" asChild className="text-muted-foreground hover:text-foreground">
            <Link href="/auth/login">Iniciar Sesion</Link>
          </Button>
          <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow">
            <Link href="/auth/sign-up">Comenzar Gratis</Link>
          </Button>
        </div>
      </div>
    </nav>
  )
}
