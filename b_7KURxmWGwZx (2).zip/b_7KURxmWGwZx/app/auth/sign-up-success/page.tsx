import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Zap, Mail, ArrowRight } from "lucide-react"

export default function SignUpSuccessPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background grid-pattern">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="relative flex flex-1 flex-col items-center justify-center px-4">
        <div className="w-full max-w-md text-center">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 neon-border">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <span className="text-2xl font-bold text-foreground">
              Viral<span className="text-primary">Mind</span>
            </span>
          </Link>

          <div className="mt-8 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-primary/20 animate-pulse-glow">
              <Mail className="h-10 w-10 text-primary" />
            </div>
          </div>

          <h1 className="mt-6 text-2xl font-bold text-foreground">Revisa tu correo</h1>
          <p className="mt-4 text-muted-foreground">
            Te hemos enviado un enlace de confirmacion. Haz clic en el enlace para activar tu cuenta
            y comenzar a crear contenido viral.
          </p>

          <div className="mt-8 glass-card rounded-lg p-4">
            <p className="text-sm text-muted-foreground">
              No recibiste el correo? Revisa tu carpeta de spam o{" "}
              <Link href="/auth/sign-up" className="text-primary hover:underline">
                intentalo de nuevo
              </Link>
            </p>
          </div>

          <Button asChild className="mt-8 bg-primary text-primary-foreground hover:bg-primary/90 neon-glow">
            <Link href="/auth/login">
              Ir a Iniciar Sesion
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </div>
    </div>
  )
}
