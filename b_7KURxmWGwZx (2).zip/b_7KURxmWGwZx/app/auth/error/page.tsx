import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Zap, AlertCircle, ArrowLeft } from "lucide-react"

export default function AuthErrorPage() {
  return (
    <div className="flex min-h-screen flex-col bg-background grid-pattern">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-destructive/10 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl" />
      </div>

      <div className="relative flex flex-1 flex-col items-center justify-center px-4">
        <div className="w-full max-w-md text-center">
          <Link href="/" className="inline-flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 neon-border">
              <Zap className="h-5 w-5 text-primary" />
            </div>
            <span className="text-2xl font-bold text-foreground">
              Viral<span className="text-primary">Mind</span>
            </span>
          </Link>

          <div className="mt-8 flex justify-center">
            <div className="flex h-20 w-20 items-center justify-center rounded-full bg-destructive/20">
              <AlertCircle className="h-10 w-10 text-destructive" />
            </div>
          </div>

          <h1 className="mt-6 text-2xl font-bold text-foreground">Error de Autenticacion</h1>
          <p className="mt-4 text-muted-foreground">
            Hubo un problema al verificar tu cuenta. El enlace puede haber expirado o ya fue utilizado.
          </p>

          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:justify-center">
            <Button asChild variant="outline" className="border-border hover:border-primary">
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Volver al inicio
              </Link>
            </Button>
            <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 neon-glow">
              <Link href="/auth/sign-up">Intentar de nuevo</Link>
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
