import { createClient } from "@/lib/supabase/server"
import { TrendsGenerator } from "@/components/dashboard/trends-generator"

export default async function TrendsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used")
    .eq("id", user?.id)
    .single()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          <span className="text-primary">Tendencias</span> en Tiempo Real
        </h1>
        <p className="mt-2 text-muted-foreground">
          Descubre las tendencias actuales de tu nicho con datos en tiempo real
        </p>
      </div>

      <TrendsGenerator 
        userId={user?.id || ""} 
        plan={profile?.plan || "free"}
        generationsUsed={profile?.generations_used || 0}
      />
    </div>
  )
}
