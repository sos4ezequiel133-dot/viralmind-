import { createClient } from "@/lib/supabase/server"
import { HookGenerator } from "@/components/dashboard/hook-generator"

export default async function HooksPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used")
    .eq("id", user?.id)
    .single()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          Creador de <span className="text-primary">Hooks</span>
        </h1>
        <p className="mt-2 text-muted-foreground">
          Genera 3 hooks irresistibles que capturan la atencion en los primeros segundos
        </p>
      </div>

      <HookGenerator 
        userId={user?.id || ""} 
        plan={profile?.plan || "free"}
        generationsUsed={profile?.generations_used || 0}
      />
    </div>
  )
}
