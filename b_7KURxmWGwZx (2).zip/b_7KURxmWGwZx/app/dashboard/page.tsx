import { createClient } from "@/lib/supabase/server"
import { IdeaGenerator } from "@/components/dashboard/idea-generator"

export default async function DashboardPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used")
    .eq("id", user?.id)
    .single()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          Generador de <span className="text-primary">Ideas Virales</span>
        </h1>
        <p className="mt-2 text-muted-foreground">
          Ingresa tu nicho o tema y recibe 5 ideas optimizadas para contenido viral
        </p>
      </div>

      <IdeaGenerator 
        userId={user?.id || ""} 
        plan={profile?.plan || "free"}
        generationsUsed={profile?.generations_used || 0}
      />
    </div>
  )
}
