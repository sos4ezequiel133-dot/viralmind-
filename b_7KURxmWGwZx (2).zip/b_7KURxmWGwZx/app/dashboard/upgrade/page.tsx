import { createClient } from "@/lib/supabase/server"
import { UpgradePlans } from "@/components/dashboard/upgrade-plans"

export default async function UpgradePage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan")
    .eq("id", user?.id)
    .single()

  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          Actualiza tu <span className="text-primary">Plan</span>
        </h1>
        <p className="mt-2 text-muted-foreground">
          Desbloquea mas generaciones y funciones premium
        </p>
      </div>

      <UpgradePlans currentPlan={profile?.plan || "free"} />
    </div>
  )
}
