import { createClient } from "@/lib/supabase/server"
import { SettingsForm } from "@/components/dashboard/settings-form"

export default async function SettingsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", user?.id)
    .single()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          <span className="text-primary">Configuracion</span>
        </h1>
        <p className="mt-2 text-muted-foreground">
          Administra tu cuenta y preferencias
        </p>
      </div>

      <SettingsForm 
        user={user} 
        profile={profile} 
      />
    </div>
  )
}
