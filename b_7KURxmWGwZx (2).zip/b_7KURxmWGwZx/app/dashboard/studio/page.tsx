"use client"

import { ContentStudio } from "@/components/dashboard/content-studio"

export default function StudioPage() {
  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Content Studio</h1>
        <p className="mt-2 text-muted-foreground">
          Tu espacio de trabajo para crear, editar y organizar contenido
        </p>
      </div>
      <ContentStudio />
    </div>
  )
}
