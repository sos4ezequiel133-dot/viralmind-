import { createClient } from "@/lib/supabase/server"
import { HistoryList } from "@/components/dashboard/history-list"

export default async function HistoryPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  // Get last 7 days of generations for free users, all for paid
  const { data: profile } = await supabase
    .from("profiles")
    .select("plan")
    .eq("id", user?.id)
    .single()

  const sevenDaysAgo = new Date()
  sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

  let query = supabase
    .from("generations")
    .select("*")
    .eq("user_id", user?.id)
    .order("created_at", { ascending: false })
    .limit(100)

  if (profile?.plan === "free") {
    query = query.gte("created_at", sevenDaysAgo.toISOString())
  }

  const { data: generations } = await query

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          <span className="text-primary">Historial</span> de Generaciones
        </h1>
        <p className="mt-2 text-muted-foreground">
          {profile?.plan === "free" 
            ? "Ultimos 7 dias de generaciones (actualiza para ver mas)"
            : "Todas tus generaciones anteriores"}
        </p>
      </div>

      <HistoryList generations={generations || []} plan={profile?.plan || "free"} />
    </div>
  )
}
