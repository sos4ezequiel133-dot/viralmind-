import { createClient } from "@/lib/supabase/server"
import { FavoritesList } from "@/components/dashboard/favorites-list"

export default async function FavoritesPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: favorites } = await supabase
    .from("generations")
    .select("*")
    .eq("user_id", user?.id)
    .eq("is_favorite", true)
    .order("created_at", { ascending: false })
    .limit(50)

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          Tus <span className="text-primary">Favoritos</span>
        </h1>
        <p className="mt-2 text-muted-foreground">
          Accede rapidamente a tus mejores generaciones guardadas
        </p>
      </div>

      <FavoritesList favorites={favorites || []} />
    </div>
  )
}
