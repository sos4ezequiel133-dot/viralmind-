import { createClient } from "@/lib/supabase/server"
import { ScriptGenerator } from "@/components/dashboard/script-generator"

export default async function ScriptsPage() {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used")
    .eq("id", user?.id)
    .single()

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-foreground sm:text-3xl">
          <span className="text-primary">Script</span> Studio
        </h1>
        <p className="mt-2 text-muted-foreground">
          Crea guiones completos optimizados para formato vertical con estructura probada
        </p>
      </div>

      <ScriptGenerator 
        userId={user?.id || ""} 
        plan={profile?.plan || "free"}
        generationsUsed={profile?.generations_used || 0}
      />
    </div>
  )
}
