import type { Metadata, Viewport } from 'next'
import { Inter, Geist_Mono } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import './globals.css'

const inter = Inter({ subsets: ["latin"], variable: "--font-inter" });
const geistMono = Geist_Mono({ subsets: ["latin"], variable: "--font-geist-mono" });

export const metadata: Metadata = {
  title: 'ViralMind - Genera Contenido Viral con IA',
  description: 'Crea ideas virales, hooks irresistibles y guiones optimizados para TikTok, Reels e YouTube Shorts con inteligencia artificial.',
  keywords: ['IA', 'contenido viral', 'TikTok', 'Reels', 'YouTube Shorts', 'creador de contenido', 'hooks', 'guiones'],
  authors: [{ name: 'ViralMind' }],
  creator: 'ViralMind',
  icons: {
    icon: [
      {
        url: '/icon-light-32x32.png',
        media: '(prefers-color-scheme: light)',
      },
      {
        url: '/icon-dark-32x32.png',
        media: '(prefers-color-scheme: dark)',
      },
      {
        url: '/icon.svg',
        type: 'image/svg+xml',
      },
    ],
    apple: '/apple-icon.png',
  },
  openGraph: {
    title: 'ViralMind - Genera Contenido Viral con IA',
    description: 'Crea ideas virales, hooks irresistibles y guiones optimizados para redes sociales.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#0a0a14',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="es" className="bg-background">
      <body className={`${inter.variable} ${geistMono.variable} font-sans antialiased`}>
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
