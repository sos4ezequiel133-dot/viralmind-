import { streamText, Output } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase/server"

const scriptSchema = z.object({
  script: z.object({
    title: z.string().describe("Titulo del video"),
    hook: z.string().describe("Hook inicial (0-3 segundos)"),
    intro: z.string().describe("Introduccion al tema (3-10 segundos)"),
    body: z.array(z.string()).describe("Puntos principales del contenido"),
    climax: z.string().describe("Momento de mayor impacto o revelacion"),
    cta: z.string().describe("Call to action final"),
    totalDuration: z.string().describe("Duracion estimada total"),
    visualNotes: z.array(z.string()).describe("Notas de produccion visual"),
  }),
})

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export async function POST(req: Request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return new Response("Unauthorized", { status: 401 })
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used, generations_reset_at")
    .eq("id", user.id)
    .single()

  const plan = profile?.plan || "free"
  const limit = planLimits[plan]
  const used = profile?.generations_used || 0

  const lastReset = new Date(profile?.generations_reset_at || 0)
  const now = new Date()
  const shouldReset = lastReset.toDateString() !== now.toDateString()

  if (shouldReset) {
    await supabase
      .from("profiles")
      .update({ generations_used: 0, generations_reset_at: now.toISOString() })
      .eq("id", user.id)
  } else if (used >= limit) {
    return new Response(JSON.stringify({ error: "Limite de generaciones alcanzado" }), {
      status: 429,
      headers: { "Content-Type": "application/json" },
    })
  }

  const { topic, duration = "60", style = "educativo", language = "es" } = await req.json()

  const systemPrompt = language === "es"
    ? `Eres un guionista profesional para videos cortos virales.
       Tu trabajo es crear guiones completos optimizados para formato vertical.
       El guion debe tener una estructura clara: hook, desarrollo, climax y CTA.
       Incluye notas de produccion para ayudar al creador con la ejecucion visual.
       Estilo solicitado: ${style}
       Duracion objetivo: ${duration} segundos
       IMPORTANTE: Responde SOLO en espanol.`
    : `You are a professional scriptwriter for viral short videos.
       Your job is to create complete scripts optimized for vertical format.
       The script should have a clear structure: hook, development, climax and CTA.
       Include production notes to help the creator with visual execution.
       Requested style: ${style}
       Target duration: ${duration} seconds`

  const result = streamText({
    model: "openai/gpt-5-mini",
    system: systemPrompt,
    prompt: `Crea un guion completo para un video sobre: "${topic}"`,
    output: Output.object({ schema: scriptSchema }),
  })

  await supabase
    .from("profiles")
    .update({ generations_used: shouldReset ? 1 : used + 1 })
    .eq("id", user.id)

  const stream = result.toTextStream()
  const chunks: string[] = []

  const transformStream = new TransformStream({
    async transform(chunk, controller) {
      chunks.push(chunk)
      controller.enqueue(chunk)
    },
    async flush() {
      try {
        const fullContent = chunks.join("")
        const parsed = JSON.parse(fullContent)
        await supabase.from("generations").insert({
          user_id: user.id,
          tool_type: "script",
          input_topic: topic,
          output_content: parsed,
        })
      } catch {
        // Ignore parsing errors
      }
    },
  })

  return new Response(stream.pipeThrough(transformStream), {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  })
}
