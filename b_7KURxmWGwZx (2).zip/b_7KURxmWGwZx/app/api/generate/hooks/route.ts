import { streamText, Output } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase/server"

const hookSchema = z.object({
  hooks: z.array(
    z.object({
      text: z.string().describe("El hook completo listo para usar"),
      type: z.string().describe("Tipo: pregunta, afirmacion impactante, historia, etc"),
      emotion: z.string().describe("Emocion principal que evoca"),
      timing: z.string().describe("Duracion sugerida en segundos"),
    })
  ),
})

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export async function POST(req: Request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return new Response("Unauthorized", { status: 401 })
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used, generations_reset_at")
    .eq("id", user.id)
    .single()

  const plan = profile?.plan || "free"
  const limit = planLimits[plan]
  const used = profile?.generations_used || 0

  const lastReset = new Date(profile?.generations_reset_at || 0)
  const now = new Date()
  const shouldReset = lastReset.toDateString() !== now.toDateString()

  if (shouldReset) {
    await supabase
      .from("profiles")
      .update({ generations_used: 0, generations_reset_at: now.toISOString() })
      .eq("id", user.id)
  } else if (used >= limit) {
    return new Response(JSON.stringify({ error: "Limite de generaciones alcanzado" }), {
      status: 429,
      headers: { "Content-Type": "application/json" },
    })
  }

  const { topic, language = "es" } = await req.json()

  const systemPrompt = language === "es"
    ? `Eres un experto en hooks virales para videos cortos.
       Tu trabajo es crear hooks que capturen la atencion en los primeros 3 segundos.
       Los hooks deben generar curiosidad, emocion o urgencia inmediata.
       Usa tecnicas probadas: preguntas retoricas, afirmaciones impactantes, historias personales.
       IMPORTANTE: Responde SOLO en espanol.`
    : `You are an expert in viral hooks for short videos.
       Your job is to create hooks that capture attention in the first 3 seconds.
       Hooks should generate curiosity, emotion or immediate urgency.
       Use proven techniques: rhetorical questions, impactful statements, personal stories.`

  const result = streamText({
    model: "openai/gpt-5-mini",
    system: systemPrompt,
    prompt: `Genera 3 hooks irresistibles para un video sobre: "${topic}"`,
    output: Output.object({ schema: hookSchema }),
  })

  await supabase
    .from("profiles")
    .update({ generations_used: shouldReset ? 1 : used + 1 })
    .eq("id", user.id)

  const stream = result.toTextStream()
  const chunks: string[] = []

  const transformStream = new TransformStream({
    async transform(chunk, controller) {
      chunks.push(chunk)
      controller.enqueue(chunk)
    },
    async flush() {
      try {
        const fullContent = chunks.join("")
        const parsed = JSON.parse(fullContent)
        await supabase.from("generations").insert({
          user_id: user.id,
          tool_type: "hook",
          input_topic: topic,
          output_content: parsed,
        })
      } catch {
        // Ignore parsing errors
      }
    },
  })

  return new Response(stream.pipeThrough(transformStream), {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  })
}
