import { streamText, Output } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase/server"

const ideaSchema = z.object({
  ideas: z.array(
    z.object({
      title: z.string().describe("Titulo corto y llamativo del video"),
      description: z.string().describe("Descripcion breve del concepto"),
      hook: z.string().describe("Hook inicial para captar atencion"),
      format: z.string().describe("Formato sugerido: tutorial, storytime, POV, etc"),
      viralScore: z.number().min(1).max(10).describe("Puntuacion de potencial viral 1-10"),
    })
  ),
})

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export async function POST(req: Request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return new Response("Unauthorized", { status: 401 })
  }

  // Check usage limits
  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used, generations_reset_at")
    .eq("id", user.id)
    .single()

  const plan = profile?.plan || "free"
  const limit = planLimits[plan]
  const used = profile?.generations_used || 0

  // Check if we need to reset (daily reset)
  const lastReset = new Date(profile?.generations_reset_at || 0)
  const now = new Date()
  const shouldReset = lastReset.toDateString() !== now.toDateString()

  if (shouldReset) {
    await supabase
      .from("profiles")
      .update({ generations_used: 0, generations_reset_at: now.toISOString() })
      .eq("id", user.id)
  } else if (used >= limit) {
    return new Response(JSON.stringify({ error: "Limite de generaciones alcanzado" }), {
      status: 429,
      headers: { "Content-Type": "application/json" },
    })
  }

  const { topic, language = "es" } = await req.json()

  const systemPrompt = language === "es"
    ? `Eres un experto en contenido viral para TikTok, Instagram Reels y YouTube Shorts.
       Tu trabajo es generar ideas de videos que tienen alto potencial de volverse virales.
       Las ideas deben ser creativas, originales y optimizadas para el formato corto vertical.
       Enfocate en tendencias actuales, emociones fuertes y contenido que genere engagement.
       IMPORTANTE: Responde SOLO en espanol.`
    : `You are an expert in viral content for TikTok, Instagram Reels and YouTube Shorts.
       Your job is to generate video ideas with high viral potential.
       Ideas should be creative, original and optimized for short vertical format.
       Focus on current trends, strong emotions and engagement-generating content.`

  const result = streamText({
    model: "openai/gpt-5-mini",
    system: systemPrompt,
    prompt: `Genera 5 ideas virales para videos sobre: "${topic}"`,
    output: Output.object({ schema: ideaSchema }),
  })

  // Increment usage count
  await supabase
    .from("profiles")
    .update({ generations_used: shouldReset ? 1 : used + 1 })
    .eq("id", user.id)

  // Save generation to history
  const stream = result.toTextStream()
  const chunks: string[] = []

  const transformStream = new TransformStream({
    async transform(chunk, controller) {
      chunks.push(chunk)
      controller.enqueue(chunk)
    },
    async flush() {
      try {
        const fullContent = chunks.join("")
        const parsed = JSON.parse(fullContent)
        await supabase.from("generations").insert({
          user_id: user.id,
          tool_type: "idea",
          input_topic: topic,
          output_content: parsed,
        })
      } catch {
        // Ignore parsing errors for partial content
      }
    },
  })

  return new Response(stream.pipeThrough(transformStream), {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  })
}
