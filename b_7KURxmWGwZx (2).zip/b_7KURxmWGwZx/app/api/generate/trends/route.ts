import { streamText, Output } from "ai"
import { z } from "zod"
import { createClient } from "@/lib/supabase/server"

const trendsSchema = z.object({
  trends: z.array(
    z.object({
      trend: z.string().describe("Nombre o descripcion de la tendencia"),
      platform: z.string().describe("Plataforma principal: TikTok, Reels, Shorts"),
      category: z.string().describe("Categoria: audio, formato, challenge, meme"),
      howToUse: z.string().describe("Como aplicar esta tendencia a tu contenido"),
      exampleIdea: z.string().describe("Idea de ejemplo para tu nicho"),
      viralPotential: z.number().min(1).max(10).describe("Potencial viral 1-10"),
    })
  ),
})

const planLimits: Record<string, number> = {
  free: 3,
  starter: 50,
  pro: 999999,
}

export async function POST(req: Request) {
  const supabase = await createClient()
  const { data: { user } } = await supabase.auth.getUser()

  if (!user) {
    return new Response("Unauthorized", { status: 401 })
  }

  const { data: profile } = await supabase
    .from("profiles")
    .select("plan, generations_used, generations_reset_at")
    .eq("id", user.id)
    .single()

  const plan = profile?.plan || "free"
  const limit = planLimits[plan]
  const used = profile?.generations_used || 0

  const lastReset = new Date(profile?.generations_reset_at || 0)
  const now = new Date()
  const shouldReset = lastReset.toDateString() !== now.toDateString()

  if (shouldReset) {
    await supabase
      .from("profiles")
      .update({ generations_used: 0, generations_reset_at: now.toISOString() })
      .eq("id", user.id)
  } else if (used >= limit) {
    return new Response(JSON.stringify({ error: "Limite de generaciones alcanzado" }), {
      status: 429,
      headers: { "Content-Type": "application/json" },
    })
  }

  const { niche, language = "es" } = await req.json()

  const systemPrompt = language === "es"
    ? `Eres un analista de tendencias de redes sociales especializado en contenido viral.
       Tu trabajo es identificar tendencias actuales y emergentes para creadores de contenido.
       Considera audios virales, formatos de video, challenges, memes y estilos de edicion.
       Proporciona tendencias relevantes y aplicables para el nicho especificado.
       IMPORTANTE: Responde SOLO en espanol. Fecha actual: ${new Date().toLocaleDateString("es")}`
    : `You are a social media trends analyst specializing in viral content.
       Your job is to identify current and emerging trends for content creators.
       Consider viral audios, video formats, challenges, memes and editing styles.
       Provide relevant and applicable trends for the specified niche.
       Current date: ${new Date().toLocaleDateString("en")}`

  const result = streamText({
    model: "openai/gpt-5-mini",
    system: systemPrompt,
    prompt: `Identifica 5 tendencias actuales relevantes para el nicho: "${niche}"`,
    output: Output.object({ schema: trendsSchema }),
  })

  await supabase
    .from("profiles")
    .update({ generations_used: shouldReset ? 1 : used + 1 })
    .eq("id", user.id)

  const stream = result.toTextStream()
  const chunks: string[] = []

  const transformStream = new TransformStream({
    async transform(chunk, controller) {
      chunks.push(chunk)
      controller.enqueue(chunk)
    },
    async flush() {
      try {
        const fullContent = chunks.join("")
        const parsed = JSON.parse(fullContent)
        await supabase.from("generations").insert({
          user_id: user.id,
          tool_type: "trend",
          input_topic: niche,
          output_content: parsed,
        })
      } catch {
        // Ignore parsing errors
      }
    },
  })

  return new Response(stream.pipeThrough(transformStream), {
    headers: { "Content-Type": "text/plain; charset=utf-8" },
  })
}
